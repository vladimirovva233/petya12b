﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicHub1.Models.Enum
{
    public enum Genre
    {
        Blues = 1,
        Rap = 2,
        PopMusic = 3,
        Rock = 4,
        Jazz = 5,
    }
}
